#!/bin/bash

options="Logout\nShutdown\nRestart\nCancel"

chosen=$(echo -e "$options" | rofi -dmenu -i -p "Exit:")

case "$chosen" in
    "Logout")
        i3-msg exit
        ;;
    "Shutdown")
        systemctl poweroff
        ;;
    "Restart")
        systemctl reboot
        ;;
    *)
        exit 0
        ;;
esac
